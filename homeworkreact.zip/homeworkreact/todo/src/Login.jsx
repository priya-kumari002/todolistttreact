import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { login, logout } from '../authActions';

const Login = () => {
  const [username, setUsername] = useState('');
  const dispatch = useDispatch();

  const handleLogin = () => {
    dispatch(login({ username }));
  };

  const handleLogout = () => {
    dispatch(logout());
  };

  return (
    <div className="login">
      {!username ? (
        <div>
          <input
            type="text"
            placeholder="Enter username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <button onClick={handleLogin}>Login</button>
        </div>
      ) : (
        <div>
          <p>Welcome, {username}</p>
          <button onClick={handleLogout}>Logout</button>
        </div>
      )}
    </div>
  );
};

export default Login;
