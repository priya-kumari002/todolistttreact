import axios from 'axios';

export const fetchTasks = () => async (dispatch) => {
  dispatch({ type: 'FETCH_TASKS_REQUEST' });
  try {
    const response = await axios.get('https://api.example.com/tasks'); // Use a relevant API
    dispatch({ type: 'FETCH_TASKS_SUCCESS', payload: response.data });
  } catch (error) {
    dispatch({ type: 'FETCH_TASKS_FAILURE', error: error.message });
  }
};

export const addTask = (task) => ({
  type: 'ADD_TASK',
  payload: task,
});

export const deleteTask = (id) => ({
  type: 'DELETE_TASK',
  payload: id,
});

export const updateTaskPriority = (id, priority) => ({
  type: 'UPDATE_TASK_PRIORITY',
  payload: { id, priority },
});
