import React from 'react';

const TaskItem = ({ task, onDelete, onPriorityChange }) => {
  return (
    <div className="task-item">
      <span>{task.text}</span>
      <span>{task.priority}</span>
      <button onClick={() => onDelete(task.id)}>Delete</button>
      <select
        value={task.priority}
        onChange={(e) => onPriorityChange(task.id, e.target.value)}
      >
        <option value="High">High</option>
        <option value="Medium">Medium</option>
        <option value="Low">Low</option>
      </select>
    </div>
  );
};

export default TaskItem;
