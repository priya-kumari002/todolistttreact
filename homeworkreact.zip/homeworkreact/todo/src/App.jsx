import React from 'react';
import { useSelector } from 'react-redux';
import TaskInput from './TaskInput';
import TaskList from './TaskList';
import Login from './Login';

function App() {
  const { isAuthenticated } = useSelector(state => state.auth);

  return (
    <div className="App">
      <Login />
      {isAuthenticated && (
        <div>
          <TaskInput />
          <TaskList />
        </div>
      )}
    </div>
  );
}

export default App;
