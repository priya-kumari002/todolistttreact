import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTasks, deleteTask, updateTaskPriority } from './todoActions';
import TaskItem from './TaskItem';

const TaskList = () => {
  const dispatch = useDispatch();
  const { tasks, loading, error } = useSelector(state => state.todos);

  useEffect(() => {
    dispatch(fetchTasks());
  }, [dispatch]);

  const handleDelete = (id) => {
    dispatch(deleteTask(id));
  };

  const handlePriorityChange = (id, priority) => {
    dispatch(updateTaskPriority(id, priority));
  };

  return (
    <div className="task-list">
      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}
      {tasks.map(task => (
        <TaskItem
          key={task.id}
          task={task}
          onDelete={handleDelete}
          onPriorityChange={handlePriorityChange}
        />
      ))}
    </div>
  );
};

export default TaskList;
