import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addTask } from './todoActions';

const TaskInput = () => {
  const [task, setTask] = useState('');
  const dispatch = useDispatch();

  const handleAddTask = () => {
    if (task.trim()) {
      const newTask = { id: Date.now(), text: task, priority: 'Low' };
      dispatch(addTask(newTask));
      setTask('');
    }
  };

  return (
    <div className="task-input">
      <input
        type="text"
        value={task}
        onChange={(e) => setTask(e.target.value)}
        placeholder="Enter your task"
      />
      <button onClick={handleAddTask}>Add Task</button>
    </div>
  );
};

export default TaskInput;
